﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMCC
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double Peso, Altura, IMC;
            if (double.TryParse(txtPeso.Text, out Peso) && (double.TryParse(txtAltura.Text, out Altura)))
            {
                if (Altura == 0)
                {
                    MessageBox.Show("Digite uma altura válida!");
                    txtAltura.Focus();
                }
                else
                {
                    IMC = Peso / Math.Pow(Altura, 2);
                    IMC = Math.Round(IMC, 1);
                    if (IMC < 18.5)
                    {
                        txtIMC.Text = "Magreza, IMC: ";
                        txtIMC.Text += IMC.ToString();
                    } else if(IMC < 24.9)
                    {                     
                        txtIMC.Text = IMC.ToString() + " Normal";
                    }
                    else if(IMC < 29.9)
                    {                        
                        txtIMC.Text += IMC.ToString() + "Sobrepeso";
                    }else if(IMC < 39.9)
                    {                       
                        txtIMC.Text += IMC.ToString() + " Obesidade";
                    }
                    else
                    {
                        txtIMC.Text = IMC.ToString() + " Obesidade Grave";
                    }
                    }
                }

            }
        }
    }

