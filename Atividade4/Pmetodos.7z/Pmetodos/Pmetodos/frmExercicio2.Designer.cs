﻿namespace Pmetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_palavra1 = new System.Windows.Forms.TextBox();
            this.txt_palavra2 = new System.Windows.Forms.TextBox();
            this.btn_verificar = new System.Windows.Forms.Button();
            this.btn_inserir1 = new System.Windows.Forms.Button();
            this.btn_inserir2 = new System.Windows.Forms.Button();
            this.lbl_palavra1 = new System.Windows.Forms.Label();
            this.lbl_palavra2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_palavra1
            // 
            this.txt_palavra1.Location = new System.Drawing.Point(278, 28);
            this.txt_palavra1.Margin = new System.Windows.Forms.Padding(4);
            this.txt_palavra1.Name = "txt_palavra1";
            this.txt_palavra1.Size = new System.Drawing.Size(124, 32);
            this.txt_palavra1.TabIndex = 0;
            // 
            // txt_palavra2
            // 
            this.txt_palavra2.Location = new System.Drawing.Point(278, 114);
            this.txt_palavra2.Margin = new System.Windows.Forms.Padding(4);
            this.txt_palavra2.Name = "txt_palavra2";
            this.txt_palavra2.Size = new System.Drawing.Size(124, 32);
            this.txt_palavra2.TabIndex = 1;
            // 
            // btn_verificar
            // 
            this.btn_verificar.Location = new System.Drawing.Point(18, 224);
            this.btn_verificar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_verificar.Name = "btn_verificar";
            this.btn_verificar.Size = new System.Drawing.Size(192, 87);
            this.btn_verificar.TabIndex = 2;
            this.btn_verificar.Text = "Verificar iguais";
            this.btn_verificar.UseVisualStyleBackColor = true;
            this.btn_verificar.Click += new System.EventHandler(this.btn_verificar_Click);
            // 
            // btn_inserir1
            // 
            this.btn_inserir1.Location = new System.Drawing.Point(243, 222);
            this.btn_inserir1.Margin = new System.Windows.Forms.Padding(4);
            this.btn_inserir1.Name = "btn_inserir1";
            this.btn_inserir1.Size = new System.Drawing.Size(176, 91);
            this.btn_inserir1.TabIndex = 3;
            this.btn_inserir1.Text = "Inserir 1° no meio do 2°";
            this.btn_inserir1.UseVisualStyleBackColor = true;
            this.btn_inserir1.Click += new System.EventHandler(this.btn_inserir1_Click);
            // 
            // btn_inserir2
            // 
            this.btn_inserir2.Location = new System.Drawing.Point(446, 224);
            this.btn_inserir2.Margin = new System.Windows.Forms.Padding(4);
            this.btn_inserir2.Name = "btn_inserir2";
            this.btn_inserir2.Size = new System.Drawing.Size(171, 91);
            this.btn_inserir2.TabIndex = 4;
            this.btn_inserir2.Text = "Inserir 2 asteriscos no meio do 1°";
            this.btn_inserir2.UseVisualStyleBackColor = true;
            this.btn_inserir2.Click += new System.EventHandler(this.btn_inserir2_Click);
            // 
            // lbl_palavra1
            // 
            this.lbl_palavra1.AutoSize = true;
            this.lbl_palavra1.Location = new System.Drawing.Point(139, 28);
            this.lbl_palavra1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_palavra1.Name = "lbl_palavra1";
            this.lbl_palavra1.Size = new System.Drawing.Size(110, 26);
            this.lbl_palavra1.TabIndex = 5;
            this.lbl_palavra1.Text = "Palavra 1:";
            this.lbl_palavra1.Click += new System.EventHandler(this.lbl_palavra1_Click);
            // 
            // lbl_palavra2
            // 
            this.lbl_palavra2.AutoSize = true;
            this.lbl_palavra2.Location = new System.Drawing.Point(143, 114);
            this.lbl_palavra2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_palavra2.Name = "lbl_palavra2";
            this.lbl_palavra2.Size = new System.Drawing.Size(110, 26);
            this.lbl_palavra2.TabIndex = 6;
            this.lbl_palavra2.Text = "Palavra 2:";
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 26F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 379);
            this.Controls.Add(this.lbl_palavra2);
            this.Controls.Add(this.lbl_palavra1);
            this.Controls.Add(this.btn_inserir2);
            this.Controls.Add(this.btn_inserir1);
            this.Controls.Add(this.btn_verificar);
            this.Controls.Add(this.txt_palavra2);
            this.Controls.Add(this.txt_palavra1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_palavra1;
        private System.Windows.Forms.TextBox txt_palavra2;
        private System.Windows.Forms.Button btn_verificar;
        private System.Windows.Forms.Button btn_inserir1;
        private System.Windows.Forms.Button btn_inserir2;
        private System.Windows.Forms.Label lbl_palavra1;
        private System.Windows.Forms.Label lbl_palavra2;
    }
}