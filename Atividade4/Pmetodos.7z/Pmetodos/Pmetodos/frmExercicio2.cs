﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btn_verificar_Click(object sender, EventArgs e)
        {
            if (string.Compare(txt_palavra1.Text, txt_palavra2.Text, true) == 0)
            {
                MessageBox.Show("São iguais");

            }
            else
            {
                MessageBox.Show("Não são iguais");
            }
        }

        private void lbl_palavra1_Click(object sender, EventArgs e)
        {

        }

        private void btn_inserir1_Click(object sender, EventArgs e)
        {
            int meio = (txt_palavra1.Text.Length / 2);
            txt_palavra2.Text = txt_palavra2.Text.Substring(0, meio) + txt_palavra1.Text + txt_palavra2.Text.Substring(meio, txt_palavra2.Text.Length - meio);
        }

        private void btn_inserir2_Click(object sender, EventArgs e)
        {
            int meio = txt_palavra1.Text.Length / 2;
            txt_palavra2.Text = txt_palavra1.Text.Insert(meio, "**");
        }
    }
}
