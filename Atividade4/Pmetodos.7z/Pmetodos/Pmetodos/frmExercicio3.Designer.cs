﻿namespace Pmetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_palavra2 = new System.Windows.Forms.Label();
            this.lbl_palavra1 = new System.Windows.Forms.Label();
            this.btn_inverte = new System.Windows.Forms.Button();
            this.btn_remover = new System.Windows.Forms.Button();
            this.txt_palavra2 = new System.Windows.Forms.TextBox();
            this.txt_palavra1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_palavra2
            // 
            this.lbl_palavra2.AutoSize = true;
            this.lbl_palavra2.Location = new System.Drawing.Point(226, 168);
            this.lbl_palavra2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_palavra2.Name = "lbl_palavra2";
            this.lbl_palavra2.Size = new System.Drawing.Size(78, 20);
            this.lbl_palavra2.TabIndex = 13;
            this.lbl_palavra2.Text = "Palavra 2:";
            // 
            // lbl_palavra1
            // 
            this.lbl_palavra1.AutoSize = true;
            this.lbl_palavra1.Location = new System.Drawing.Point(222, 82);
            this.lbl_palavra1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_palavra1.Name = "lbl_palavra1";
            this.lbl_palavra1.Size = new System.Drawing.Size(78, 20);
            this.lbl_palavra1.TabIndex = 12;
            this.lbl_palavra1.Text = "Palavra 1:";
            // 
            // btn_inverte
            // 
            this.btn_inverte.Location = new System.Drawing.Point(452, 278);
            this.btn_inverte.Margin = new System.Windows.Forms.Padding(4);
            this.btn_inverte.Name = "btn_inverte";
            this.btn_inverte.Size = new System.Drawing.Size(171, 91);
            this.btn_inverte.TabIndex = 11;
            this.btn_inverte.Text = "Inverte o primeiro";
            this.btn_inverte.UseVisualStyleBackColor = true;
            this.btn_inverte.Click += new System.EventHandler(this.btn_inverte_Click);
            // 
            // btn_remover
            // 
            this.btn_remover.Location = new System.Drawing.Point(183, 278);
            this.btn_remover.Margin = new System.Windows.Forms.Padding(4);
            this.btn_remover.Name = "btn_remover";
            this.btn_remover.Size = new System.Drawing.Size(176, 91);
            this.btn_remover.TabIndex = 10;
            this.btn_remover.Text = "Remove 1° na do 2°";
            this.btn_remover.UseVisualStyleBackColor = true;
            this.btn_remover.Click += new System.EventHandler(this.btn_remover_Click);
            // 
            // txt_palavra2
            // 
            this.txt_palavra2.Location = new System.Drawing.Point(361, 168);
            this.txt_palavra2.Margin = new System.Windows.Forms.Padding(4);
            this.txt_palavra2.Name = "txt_palavra2";
            this.txt_palavra2.Size = new System.Drawing.Size(124, 26);
            this.txt_palavra2.TabIndex = 8;
            // 
            // txt_palavra1
            // 
            this.txt_palavra1.Location = new System.Drawing.Point(361, 82);
            this.txt_palavra1.Margin = new System.Windows.Forms.Padding(4);
            this.txt_palavra1.Name = "txt_palavra1";
            this.txt_palavra1.Size = new System.Drawing.Size(124, 26);
            this.txt_palavra1.TabIndex = 7;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbl_palavra2);
            this.Controls.Add(this.lbl_palavra1);
            this.Controls.Add(this.btn_inverte);
            this.Controls.Add(this.btn_remover);
            this.Controls.Add(this.txt_palavra2);
            this.Controls.Add(this.txt_palavra1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_palavra2;
        private System.Windows.Forms.Label lbl_palavra1;
        private System.Windows.Forms.Button btn_inverte;
        private System.Windows.Forms.Button btn_remover;
        private System.Windows.Forms.TextBox txt_palavra2;
        private System.Windows.Forms.TextBox txt_palavra1;
    }
}