﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btn_remover_Click(object sender, EventArgs e)
        {
            txt_palavra2.Text = txt_palavra2.Text.Replace(txt_palavra1.Text, "");
        }

        private void btn_inverte_Click(object sender, EventArgs e)
        {
            char[] vetor = txt_palavra1.Text.ToCharArray();
            Array.Reverse(vetor);
            string auxiliar = new string(vetor);
            txt_palavra2.Text = auxiliar;
        }
    }
}
