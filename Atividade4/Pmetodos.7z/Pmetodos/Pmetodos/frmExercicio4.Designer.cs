﻿namespace Pmetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btn_contanumeros = new System.Windows.Forms.Button();
            this.btn_espacobranco = new System.Windows.Forms.Button();
            this.btn_contaletras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(106, 39);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(354, 169);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btn_contanumeros
            // 
            this.btn_contanumeros.Location = new System.Drawing.Point(57, 264);
            this.btn_contanumeros.Name = "btn_contanumeros";
            this.btn_contanumeros.Size = new System.Drawing.Size(124, 72);
            this.btn_contanumeros.TabIndex = 1;
            this.btn_contanumeros.Text = "Quantidade de números";
            this.btn_contanumeros.UseVisualStyleBackColor = true;
            this.btn_contanumeros.Click += new System.EventHandler(this.btn_contanumeros_Click);
            // 
            // btn_espacobranco
            // 
            this.btn_espacobranco.Location = new System.Drawing.Point(233, 264);
            this.btn_espacobranco.Name = "btn_espacobranco";
            this.btn_espacobranco.Size = new System.Drawing.Size(110, 72);
            this.btn_espacobranco.TabIndex = 2;
            this.btn_espacobranco.Text = "1° Caracter branco";
            this.btn_espacobranco.UseVisualStyleBackColor = true;
            this.btn_espacobranco.Click += new System.EventHandler(this.btn_espacobranco_Click);
            // 
            // btn_contaletras
            // 
            this.btn_contaletras.Location = new System.Drawing.Point(390, 264);
            this.btn_contaletras.Name = "btn_contaletras";
            this.btn_contaletras.Size = new System.Drawing.Size(145, 72);
            this.btn_contaletras.TabIndex = 3;
            this.btn_contaletras.Text = "Quantidade de caracteres alfabéticos";
            this.btn_contaletras.UseVisualStyleBackColor = true;
            this.btn_contaletras.Click += new System.EventHandler(this.btn_contaletras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(591, 392);
            this.Controls.Add(this.btn_contaletras);
            this.Controls.Add(this.btn_espacobranco);
            this.Controls.Add(this.btn_contanumeros);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btn_contanumeros;
        private System.Windows.Forms.Button btn_espacobranco;
        private System.Windows.Forms.Button btn_contaletras;
    }
}