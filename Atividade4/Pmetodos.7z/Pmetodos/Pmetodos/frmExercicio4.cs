﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btn_contanumeros_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contaNum = 0;
            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[contador]))
                {
                    contaNum++;
                }
                contador++;
            }
            MessageBox.Show($"o texto tem {contaNum} números");
        }

        private void btn_espacobranco_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    MessageBox.Show($"A posição do primeiro caracter branco é {i+1}");
                    break;
                }
            }
        }

        private void btn_contaletras_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;
            foreach(char  c in rchtxtFrase.Text)
            {
                if ( char.IsLetter(c))
                {
                    contaLetra++;
                }
            }
            MessageBox.Show($"A quantidade de letras é {contaLetra}");
        }
    }
}
