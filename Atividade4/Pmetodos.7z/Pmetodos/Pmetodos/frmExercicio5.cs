﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnsorteio_Click(object sender, EventArgs e)
        {
            int n1;
            int n2;
            if (!int.TryParse(txt_num1.Text, out n1) || (!int.TryParse(txt_num2.Text, out n2)) || (n1 <= 0) || (n2 <= 0))
            {
                MessageBox.Show("Dados inválidos");

            }
            else if (n2 < n1)
            {
                MessageBox.Show("O número 2 deve ser maior que o 1");
            }
            else
            {
                Random Obj = new Random();
                int r = Obj.Next(n1, n2);
                MessageBox.Show(r.ToString());
            }


        }
    }
}
