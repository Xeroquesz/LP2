﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Exercício4 : Form
    {
        public Exercício4()
        {
            InitializeComponent();
        }
        private void Exercício4_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void btn_exe_Click(object sender, EventArgs e)
        {
            string[] Nomes = new string[10];
            int[] Caracter = new int[10];
            string auxiliar = "";

            for(int i = 0; i < 10; i++)
            {
                Nomes[i] = Interaction.InputBox($"Digite o nome da {i + 1}º pessoa: ", "Entrada de dados");
                auxiliar = Nomes[i].Replace(" ", "");
                Caracter[i] = auxiliar.Length;
                listBox1.Items.Add($"Nome: {Nomes[i]}. Este nome possui:{Caracter[i]}. caracteres.");
            }
            
        }
    }
}
