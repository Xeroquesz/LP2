﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_exe1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite 20 números: ", "Entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido!");
                    i--;
                }

            }
            Array.Reverse(vetor);
            auxiliar = "";
            auxiliar = string.Join("\n", vetor);
            MessageBox.Show(auxiliar);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ArrayList Lista = new ArrayList() { "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio",
                                                "Marcelo", "Pedro", "Thais"};
            Lista.Remove("Otávio");
            string auxiliar = "";
            foreach(string nome in Lista)
            {
                auxiliar += nome + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double[,] Notas = new double[2, 3];
            string saida="";
            string auxiliar = "";
            double media = 0;
            for (int i = 0; i < 2; i++)
            {
                media = 0;
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}", "Entrada de dados");
                    if (!double.TryParse(auxiliar, out Notas[i, j]) || Notas[i, j] < 0 || Notas[i, j] > 10)
                    {
                        MessageBox.Show("Dado inválido!");
                        j--;
                    }
                    else
                    {
                        media += Notas[i, j];
                    }
                    
                }
                saida += $"Aluno: {i + 1} : média: {media / 3}\n";
            }

            MessageBox.Show(saida);

        }

        private void button4_Click(object sender, EventArgs e)
        {

            if (Application.OpenForms.OfType<Exercício4>().Count() > 0)
            {
                Application.OpenForms["Exercício4"].BringToFront();
            }
            else
            {
                Exercício4 Exe4 = new Exercício4();
                Exe4.Show();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercício5>().Count() > 0)
            {
                Application.OpenForms["frmExercício5"].BringToFront();
            }
            else
            {
                frmExercício5 Exe5 = new frmExercício5();
                Exe5.Show();
            }
        }
    }
}
