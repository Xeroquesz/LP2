﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace PMatrizes
{
    public partial class frmExercício5 : Form
    {
        public frmExercício5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[,] Resposta = new string[2, 10];
            string[] gabarito = { "B", "C", "D", "A", "E", "B", "A", "B", "C", "E" };
            for(int i = 0; i < 2; i++)
            {
               for(int j = 0; j < 10; j++)
                {
                    Resposta[i, j] = Interaction.InputBox($"Digite a {j + 1}º resposta.", "Entrada de dados");
                    if (Resposta[i, j] != gabarito[j])
                    {
                        listBox1.Items.Add($"O Aluno {i + 1} errou a questão {j + 1}. Era {gabarito[j]}. Colocou {Resposta[i, j]}");
                    }
                    else
                    {
                        listBox1.Items.Add($"O Aluno {i + 1} acertou a questão {j + 1}. Era {gabarito[j]}. Colocou {Resposta[i, j]}");
                    }
                }
            }

        }
    }
}
