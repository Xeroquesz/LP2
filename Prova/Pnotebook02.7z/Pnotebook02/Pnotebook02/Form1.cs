﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pnotebook02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Executar_Click(object sender, EventArgs e)
        {
            double[,] Notebook = new double[2, 3];
            string Auxiliar;
            double media_geral = 0;
            double media_note1 = 0;
            double media_note2 = 0;
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Auxiliar = Interaction.InputBox($"Digite os valores do {j + 1}º notebook na {i + 1}º loja: ", "Entrada de dados da loja");
                    if (!Double.TryParse(Auxiliar, out Notebook[i, j]) || Notebook[i, j] < 0)
                    {
                        MessageBox.Show("Valor inválido!");
                        j--;

                    }
                    else
                    {

                        media_geral += Notebook[i, j] / 6;
                    }

                }

            }
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                    if (i == 0)
                    {
                        media_note1 += Notebook[i, j] / 3;
                       
                    }
                    else
                    {
                        media_note2 += Notebook[i, j] / 3;
                      
                    }
            }
            
            lst_Resul.Items.Add($"Notebook1: Loja1:{Notebook[0, 0]:C2} Loja2:{Notebook[0, 1]:C2} Loja3:{Notebook[0, 2]:C2} Media:{media_note1:C2}");
            lst_Resul.Items.Add($"Notebook2: Loja1:{Notebook[1, 0]:C2} Loja2:{Notebook[1, 1]:C2} Loja3:{Notebook[1, 2]:C2} Media:{media_note2:C2}");
            lst_Resul.Items.Add($"Média geral computadores: {media_geral:C2}");
        }

        private void btn_Limpar_Click(object sender, EventArgs e)
        {
            lst_Resul.Items.Clear();
        }
    }
}
